import sqlite3
import tkinter
import tkinter.messagebox as tk
from tkinter.font import Font
from easygui import *
from tkinter import *
from turtle import *
import random

conn = sqlite3.connect('leaveDb.db')
cur = conn.cursor()

root = Tk()
root.wm_attributes('-fullscreen', '1')
root.title("Admin Login")
root.iconbitmap(default='leavelogo.ico')
filename = PhotoImage(file="background.gif")
background_label = Label(root, image=filename)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
BtnFont = Font(family='Calibri(Body)', size=20)
MainLabel = Label(root, text="Admin Login", bd=12, relief=GROOVE, fg="White", bg="blue",
                  font=("Calibri", 36, "bold"), pady=3)



def EmployeeAllInformationWindow():
    allEmployeeInformation = Toplevel()
    txt = Text(allEmployeeInformation)
    for i in conn.execute('SELECT employee_id,Name,ContactNumber FROM employee'):
        txt.insert(INSERT, i)
        txt.insert(INSERT, '\n')

    txt.pack()

def leavelist():
    leavelistwindow = Toplevel()
    txt = Text(leavelistwindow)
    for i in conn.execute('SELECT * FROM status'):
        txt.insert(INSERT, i)
        txt.insert(INSERT, '\n')

    txt.pack()
def Shifting_form():
    root.destroy()
    import leavesystem
def Shifting_form2():
    root.destroy()
    import employee
def LeaveApproval():
    global balance2, balance1, balance, exampleDays
    message = "Enter leave_id"
    title = "leave approval"
    fieldNames = ["Leave_id"]
    fieldValues = []
    fieldValues = multenterbox(message, title, fieldNames)
    message1 = "Approve/Deny"
    title1 = "leave approval"
    choices = ["approve", "deny"]
    choice = choicebox(message1, title1, choices)

    conn.execute("UPDATE status SET status = ? WHERE leave_id= ?", (choice, fieldValues[0]))
    conn.commit()

    if choice == 'approve':
        print(0)
        cur.execute("SELECT leave FROM status WHERE leave_id=?", (fieldValues[0],))
        row = cur.fetchall()
        col = row

        for row in conn.execute("SELECT employee_id FROM status WHERE leave_id=?", (fieldValues[0],)):
            print(2)
            exampleId = row[0]

        for row in conn.execute("SELECT days FROM status WHERE leave_id=?", (fieldValues[0],)):
            print(2)
            exampleDays = row[0]

        for row in conn.execute("SELECT sickleave from balance where employee_id=?", (exampleId,)):
            balance = row[0]
            print(balance)

        for row in conn.execute("SELECT maternityleave from balance where employee_id=?", (exampleId,)):
            balance1 = row[0]
            print(balance1)

        for row in conn.execute("SELECT emergencyleave from balance where employee_id=?", (exampleId,)):
            balance2 = row[0]
            print(balance2)

        if (col[0] == ('sickleave',)):
            print(3)
            conn.execute("UPDATE balance SET sickleave =? WHERE employee_id= ?", ((balance - exampleDays), (exampleId)))

        if (col[0] == ('maternityleave',)):
            print(3)
            conn.execute("UPDATE balance SET maternityleave =? WHERE employee_id= ?", ((balance1 - exampleDays), (exampleId)))

        if (col[0] == ('emergencyleave',)):
            print(3)
            conn.execute("UPDATE balance SET emergencyleave =? WHERE employee_id= ?", ((balance2 - exampleDays), (exampleId)))



informationEmployee = Button(root, text='All Employee information', command=EmployeeAllInformationWindow, bd=12,
                             relief=GROOVE, fg="blue", bg="#ffffb3",
                             font=("Calibri", 36, "bold"), pady=3)
informationEmployee['font'] = BtnFont
informationEmployee.pack(fill=X)

LeaveListButton = Button(root, text='Leave approval list', command=leavelist, bd=12, relief=GROOVE, fg="blue",
                         bg="#ffffb3",
                         font=("Calibri", 36, "bold"), pady=3)
LeaveListButton['font'] = BtnFont
LeaveListButton.pack(fill=X)

ApprovalButton = Button(root, text='Approve leave', command=LeaveApproval, bd=12, relief=GROOVE, fg="blue",
                        bg="#ffffb3",
                        font=("Calibri", 36, "bold"), pady=3)
ApprovalButton['font'] = BtnFont
ApprovalButton.pack(fill=X)
EmpMngBtn =Button(root,text='Employee Management System',command=Shifting_form2,bd=12,relief=GROOVE,fg='sky blue',bg="#ffffb3",font=("Calibri", 36, "bold"), pady=3)
EmpMngBtn.pack(fill=X)
LogoutBtn = Button(root, text='Logout', command=Shifting_form, bd=12, relief=GROOVE, fg="red",
                   bg="#ffffb3",
                   font=("Calibri", 36, "bold"), pady=3)
LogoutBtn['font'] = BtnFont
LogoutBtn.pack(fill=X)

informationEmployee.pack()
LeaveListButton.pack()
ApprovalButton.pack()
root.mainloop()